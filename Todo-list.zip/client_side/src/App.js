import React, { useEffect, useState } from 'react';
import axios from 'axios';

const App = () => {
  const [tasks, setTasks] = useState([]);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState('pending');
  const [token, setToken] = useState('');

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    try {
      const response = await axios.get('http://localhost:3000/tasks', {
        headers: { Authorization: token },
      });
      setTasks(response.data);
    } catch (error) {
      console.error('Failed to fetch tasks:', error.message);
    }
  };

  const createTask = async () => {
    try {
      await axios.post(
        'http://localhost:3000/tasks',
        { name, description, status },
        { headers: { Authorization: token } }
      );
      fetchTasks();
      setName('');
      setDescription('');
      setStatus('pending');
    } catch (error) {
      console.error('Failed to create task:', error.message);
    }
  };

  const deleteTask = async (id) => {
    try {
      await axios.delete(`http://localhost:3000/tasks/${id}`, {
        headers: { Authorization: token },
      });
      fetchTasks();
    } catch (error) {
      console.error('Failed to delete task:', error.message);
    }
  };

  const handleLogin = async () => {
    try {
      const response = await axios.post('http://localhost:3000/login', {
        username: 'your-username',
        password: 'your-password',
      });
      setToken(response.data.token);
    } catch (error) {
      console.error('Failed to log in:', error.message);
    }
  };

  return (
    <div>
      <h1>Todo App</h1>

      {token ? (
        <div>
          <h2>Create Task</h2>
          <form
            onSubmit={(event) => {
              event.preventDefault();
              createTask();
            }}
          >
            <label htmlFor="name">Name:</label>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(event) => setName(event.target.value)}
              required
            />
            <label htmlFor="description">Description:</label>
            <input
              type="text"
              id="description"
              value={description}
              onChange={(event) => setDescription(event.target.value)}
            />
            <label htmlFor="status">Status:</label>
            <select
              id="status"
              value={status}
              onChange={(event) => setStatus(event.target.value)}
            >
              <option value="pending">Pending</option>
              <option value="completed">Completed</option>
            </select>
            <button type="submit">Create</button>
          </form>

          <h2>Tasks</h2>
          <ul>
            {tasks.map((task) => (
              <li key={task._id}>
                <strong>{task.name}</strong> - {task.description} ({task.status})
                <button onClick={() => deleteTask(task._id)}>Delete</button>
              </li>
            ))}
          </ul>
        </div>
      ) : (
        <button onClick={handleLogin}>Log In</button>
      )}
    </div>
  );
};

export default App;
